<?php 

$conn= new mysqli('localhost','root','','cafe')or die("Could not connect to mysql".mysqli_error($con));
