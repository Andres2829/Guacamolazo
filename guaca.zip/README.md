# Sistema Punto de venta (TPV) Para Cafeterías

<img src="Sistema%20Punto%20de%20venta%20(TPV)%20Para%20Cafeterias.png">

# Aspectos Funcionales

Este Sistema Punto de venta (TPV) Para Cafeterías en PHP y MySQL le permite realizar los siguientes procesos al usuario Administrador:

Agregar, Editar y Eliminar Usuarios de tipo Staff y de tipo Administrador
Cambiar el nombre del sistema
Validar e Imprimir el reporte de ventas por mes
Agregar, Editar y Eliminar Productos y Categorías
Gestionar directamente las órdenes de los Clientes, Tomar Órdenes y Recibir los Pagos de los clientes.
El usuario de tipo Staff solo tiene las opciones de Gestión de Órdenes, Tomar Órdenes, Recibir los Pagos de los clientes, y Editar Ver y Eliminar las órdenes.

# Importante

La aplicación tiene un coste de 15 USD y para su implementación requieres la base de datos y es la que te proveo a cambio del importe.

# Enlace demo de la aplicación

https://mauriciosevilla.com/cafeteria/login.php 
Usuario: configuroweb
Clave: 1234abcd..

# Contacto

Me puedes contactar directamente a mi whats en el siguiente número
https://configuroweb.com/WhatsappMessenger

# El siguiente es el post relacionado con la aplicación

https://www.configuroweb.com/sistema-punto-de-venta-tpv-para-cafeterias/
